# updated version
# last update 27 November 2025

# in this ***VERY LONG*** session we will learn how to deal with missing data
# in a fully Bayesian perspective by means of the 
# conditional (data) joint distribution of whatever is unobserved or unknown
# given whatever is observed

### 1.  Reading Pima Indian dataset ----

rm(list=ls())
pima <- read.csv("pima-missing.csv")
str(pima)
head(pima)

# 200 Indian women of age >21 were tested for diabetes according to World Health Organization criteria. The data were collected by the US National Institute of Diabetes and Digestive and Kidney Diseases

# data contain 4 main physiological measurements with, possibly, some missing measurement for each woman

# glu (blood plasma glucose concentration) 
# bp (diastolic blood pressure)
# skin (skin fold thickness)
# bmi (body mass index)

str(pima)
dim(pima)
head(pima)

mean(pima$bmi,na.rm=TRUE)
# pima

library(car)
scatterplotMatrix(~bmi+bp+glu+skin,  ellipse=FALSE, data=pima)

### 2.  Exploring the presence of missing data: how many and where are they? ----
# 
# let us investigate the presence and the pattern of missing-ness
# and then its consequence on the completeness of records

is.na(pima)
sum(is.na(pima))
head(is.na(pima))
head(!is.na(pima))

available_indicator <- (!is.na(pima))
mode(available_indicator)
mode(available_indicator) <- "numeric"
available_indicator
head(available_indicator)

sum(is.na(pima))
sum(!is.na(pima))
dim(pima)


### 3.  Exploring the presence of missing data: what impact on the completeness of records ----



# **Overall**
prod(dim(pima))
# this is to get what is the number of entries in the dataset
mean(is.na(pima))
# this is to get the relative frequency of missing data in all entries

# ==> overall there are roughly 10% of the cells of the data matrix missing

# but ....
# **By row/unit/woman**

# some units have no missing entry, others have one or more than one ...

# we can manipulate the number of missing entry of each unit
rowSums(is.na(pima))
table(rowSums(is.na(pima)))
127/200         # 63.50 of complete data entries
(200-127)/200   # 36.50 of incomplete data entries
                # possibly with more than one missing entry
                # among teh 4 measurements              

# manipulations alternative to rowSums
apply(is.na(pima),1,sum)

# alternative way of getting the completa data units/rows/women
# the complete.cases(...) function
head(pima)
head(complete.cases(pima))

# this is the number of units (rows) with 0/no missing entry
sum(complete.cases(pima))
sum(apply(is.na(pima),1,sum)==0)
# this is the % of units with 0/no missing entry
mean(apply(is.na(pima),1,sum)==0)*100

# Remember that when you have 
# vectors with missing data NA entries 
# the result of a vector operation like mean(...) or sum(...)
# returns a missing value NA

mean(c(1,2,NA))
sum(c(NA,2,4))

# In order to compute the mean(...) or the sum(...) 
# of the available (non NA) entries 
# one must set the argument na.rm=TRUE

mean(c(1,2,NA),na.rm=TRUE)
sum(c(NA,2,4),na.rm=TRUE)

# **By col/variable/measurement**

# on the other hand ....
# we can manipulate the number of missing entry of each variable
apply(pima,2,sum)
apply(pima,2,sum,na.rm=TRUE)
colSums(is.na(pima))

dim(pima)
apply(pima,2,mean)
apply(pima,2,mean,na.rm=TRUE)
mean(pima[,4],na.rm=TRUE)

# how many incomplete rows?
head(pima)
complete.cases(head(pima))
complete.cases(pima)

# absolute frequency of valid cases/rows/units are ...
sum(!complete.cases(pima))
# absolute frequency of incomplete cases/rows/units are ...
sum(complete.cases(pima))
# 
# relative frequency of valid cases/rows/units are ...
mean(!complete.cases(pima))
# relative frequency of incomplete cases/rows/units are ...
mean(complete.cases(pima))

# on the other hand ... how many COMPLETE rows as a percentage of the cases?
mean(complete.cases(pima))*100


### 4.  Connections between notations in the PH book (or slides) and the R syntax----

# What about the "o" subset of indexes which represents the observation poattern of each unit?

head(pima)

pima[2,]
is.na(pima[2,])
!is.na(pima[2,])

which(is.na(pima[2,]))
which(!is.na(pima[2,]))

m <- which(is.na(pima[2,]))
m
o <- which(!is.na(pima[2,]))
o

pima[2,o]
pima[2,m]

### 5.  Summaries of the available Pima Indian data ----
# continue description of the dataset

# what about sample averages of each variable?
colMeans(pima,na.rm=TRUE)
apply(pima,2,mean,na.rm=TRUE)
apply(pima,2,range,na.rm=TRUE)

# with the availabe data of each column (possibly qith a different number of units)
colSums(!is.na(pima))
# we can compute the (available) sample averages
colMeans(pima)
colMeans(pima,na.rm=TRUE)

y_bar_n <- colMeans(pima,na.rm=TRUE) # sample averages of each variable/measurement

# Fundamental inferential questions in the presence of missing data 

# Should we remove all rows with at least one missing data?
# Answer: NO!
# Our Bayesian framework will come to our rescue by means of 
# - its theoretical framework + 
# - some practice with the MCMC algorithm named Gibbs Sampling

# Let us see why and how ..... 


### 6.  The Bayesian approach in practice: prior distribution first ----

current_multi_normal_data=pima
p <- ncol(current_multi_normal_data)
n <- nrow(current_multi_normal_data)

p
n

# First of all ... let us elicit our prior distributions

# average physiological parameters on healthy population are known to be 

mu_0 = c(120,64,26,26)
sd0=mu_0/2

# we assume a variance covariance matrix with variances 
# such that the corresponding sd are half of the value 
# of the corresponding prior mean and slight correlation (0.1)

# Remember that Lambda_0 contains 
# covariances in the extra-diagonal entries

Lambda_0 = matrix(.1,nrow=p,ncol=p)
Lambda_0 = Lambda_0*outer(sd0,sd0)
diag(Lambda_0) = sd0^2 
Lambda_0  # we could think of this "temporary" matrix 
          # as a way of specifying the correlation 
          # hence we should multiply all entries 
          # by the product of the standard deviations
          # corresponding to the two variables involved

eigen(Lambda_0)
eigen(Lambda_0)$values
all(eigen(Lambda_0)$values>0)

# outer(sd0,sd0)
# 
# Lambda_0

# correlation matrix computation:

# divide each variance-covariance entry 
Lambda_0
# by the square root of the product of the corresponding 
# of the corresponding variances
diag(Lambda_0) # variances 
# all possible products of variances
diag(Lambda_0)%*%t(diag(Lambda_0))
# were diag(Lambda_0) is understood as a column vector

# here is the final result of the reference **correlation matrix** elicited

Lambda_0/sqrt(diag(Lambda_0)%*%t(diag(Lambda_0)))

# Lambda_0/sqrt(outer(diag(Lambda_0),diag(Lambda_0)))
# round(Lambda_0/sqrt(outer(diag(Lambda_0),diag(Lambda_0))),5)

# for illustrative purposes
# let us simulate from ***prior*** multivariate normal 
# mean parameter vector (theta)
library(car)
library(mvtnorm)
pp <- rmvnorm(1000,mu_0,Lambda_0)
pp <- data.frame(pp)
names(pp) <-  paste0("theta",1:4)
scatterplotMatrix( ~ theta1+theta2+theta3+theta4, ellipse=FALSE, data=pp,pch=".",main="Simulations from the prior of the mean vector (theta)")

# warnings()

nu_0 <- p+2
S_0 <- Lambda_0         #  a convenient way of specifying the 
                     #  some presence of correlation 
                     #  in the unknown variance covariance matrix

# 
# now you try to simulate from prior 
# inverse Wishart variance-covariance matrix parameter (Sigma)
# 

# .........

# or use the rWishart(...) function

### 7.  The Bayesian approach in practice: get ready to implement the Gibbs sampling (GS) ----

### Now let us implement our Gibbs sampling 

set.seed(123)
nsim <- 1000  # it will take a few minutes 

# we specify separate objects 
# for both parameter block-component 
# (theta, Sigma)

gibbs_sample_theta=matrix(99,nrow=nsim,ncol=length(mu_0))
head(gibbs_sample_theta)

# in order to easily track the mcmc simulations of Sigma 
# we use an array(...) data structure 
# [it generalizes the matrix class to more than 2 dimensions]
# and to easen the visualization of the differnt matrix we 
# reserve the last (third) index for the simulation index i

gibbs_sample_Sigma=array(88,c(nrow(Lambda_0),ncol(Lambda_0),nsim))
gibbs_sample_Sigma[,,1:3]

# Let's put all the simulations into a 
# matrix with nsim rows
# each row contains the vectorized parameters 
# (vector of means an variance-covariance matrix entries)

gibbs_sample_joint=matrix(NA,nrow=nsim,ncol=length(mu_0)+nrow(Lambda_0)*ncol(Lambda_0))

head(gibbs_sample_joint)
dim(gibbs_sample_joint)

gibbs_sample_joint[,1:length(mu_0)]=gibbs_sample_theta
head(gibbs_sample_joint)
gibbs_sample_joint[,(length(mu_0)+1):ncol(gibbs_sample_joint)]=array(gibbs_sample_Sigma,c(nrow(Lambda_0)*ncol(Lambda_0),nsim))
head(gibbs_sample_joint)

colnames(gibbs_sample_joint)=c(paste0("theta[",1:length(mu_0),"]"),paste0("Sigma[",paste(rep(1:ncol(Lambda_0),nrow(Lambda_0)),rep(1:nrow(Lambda_0),each=ncol(Lambda_0)),sep=","),"]"))

head(gibbs_sample_joint)

# initialize
# starting/current theta

theta <- y_bar_n  # careful *******!! 
               # from now on you should *****always ask 
               # how y_bar_n is computed 
               # with the removal of missing data? 
               # or with imputed/completed data? 

# here we have not yet imputed/initialized the missing data entries 

gibbs_sample_theta[1,] <- theta
head(gibbs_sample_theta)

n <- nrow(current_multi_normal_data)

# I start the for loop of the Gibbs sampling from t=2 
# so that I can still see the initialization 
# in the first row of the Gibbs-sampled vectors

head(current_multi_normal_data)

### 8.  The Bayesian approach in practice: a new task for the inizialization of the GS  ----

# *BUT* I need to initialize the starting imputation of the missing data in the original Pima data 
sum(is.na(current_multi_normal_data))
current_multi_normal_data[is.na(pima)]

head(current_multi_normal_data)
# this matrix will change at each (current) iteration of the Gibbs Sampling
mu_0
r <- 1
current_multi_normal_data[r,]
r <- 4
current_multi_normal_data[r,]
# r is row index
# r=4
# we initialize the current_multi_normal_data (COMPLETED DATA) matrix with a for loop
for(r in 1:nrow(current_multi_normal_data)){
  m <- is.na(current_multi_normal_data[r,])
  current_multi_normal_data[r,m]=mu_0[m]
}

# let us check the difference between the original data 
# with missing entries 
head(pima)

# and the initialized complete data entries imputed 
# only for starting the GS
# with the prior mean mu_0 components
mu_0
# alternatively 
# we could have used tje the rule-of-thumb 
# current_multi_normal_data[r,m]=y_bar_n[m]
head(current_multi_normal_data)


any(is.na(current_multi_normal_data))
sum(is.na(current_multi_normal_data))
head(current_multi_normal_data)

# Note that we could choose a somewhat arbitrary criterion to impute
# the missing values in this initialization step
# BUT ONLY HERE WE CAN MAKE ARBITARY CHOICES
sum(is.na(current_multi_normal_data))

# other methods: 
#  - mean imputation 
#  - hot deck imputation 

# note that we will be using current_multi_normal_data
# later in the generic i-th iteration of the Gibbs Sampling
# and since the "imputation" will change at each iteration ...
# we will need an appropriate object to store all these "imputations"


### 10.  The Bayesian approach in practice: another novel task ... ---

# Now we can recycle the previous Gibbs Sampling code developed for the 
# mathscore example since my data is complete!! .... but .... 

# .... what should we change 

# at the end of the previous gibbs_sampler cycle .... ? 

sum(is.na(current_multi_normal_data))

array_with_inferred_imputed_data=array(NA,dim=c(dim(pima),nsim))
dim(array_with_inferred_imputed_data)
sum(is.na(array_with_inferred_imputed_data))

array_with_inferred_imputed_data[,,1:3]

# which(is.na(pima[,4]))
# dim(array_with_inferred_imputed_data[is.na(pima[,4]),4,])
# apply(array_with_inferred_imputed_data[is.na(pima[,4]),4,],1,mean)

### 9.  The Bayesian approach in practice: another novel task ... ----

o1 <- proc.time()
i=1
for(i in 2:nsim){
  
  # print(i)
  # the following line of code is very important and NON REDUNTANT !!
  # !! CAN YOU TEL WHY???
  y_bar_n <- colMeans(current_multi_normal_data)
  
  # FIRST BLOCK of G-S cycle: update/sample Sigma from the current full-conditional
  # or better sample its inverse first
  # using the rWishart(...) function
  
  S_theta= (t(current_multi_normal_data)-theta)%*%t((t(current_multi_normal_data)-theta))
  
  S_n = S_0 + S_theta
  
  Sigma=solve(rWishart(n=1,df=n+nu_0,Sigma = solve(S_n))[,,1])
  
  # NOTE THAT Sigma = ... is the syntax for the argument of the rWishart function!! It corresponds to our S argument/parameter of the Wishart
  
  # record/store the sampled covariance matrix
  gibbs_sample_Sigma[,,i]=Sigma
  # now Sigma is the current/update covariance matrix and we condition on this Sigma matrix to sample the mean vector theta
  # SECOND BLOCK of G-S cycle: update/sample theta vector from the current full-conditional
  # compute the new parameters of the full conditionals for the unknow mean vector component
  Lambda_n = solve( solve(Lambda_0) + n *solve(Sigma))
  mu_n = Lambda_n%*%(solve(Lambda_0)%*%mu_0 + n *solve(Sigma)%*%y_bar_n)
  theta=c(rmvnorm(n=1,mean=mu_n,sigma=Lambda_n))
  gibbs_sample_theta[i,]=theta
  
  #   .... AT THE END OF THE PREVIOUS GIBBS_SAMPLER CYCLE .... 
  # ... I MUST CONSIDER THAT THE complete data (imputed with the prior means) ... are not actually known and I should deal with them if the were uknown parameters and I should draw from the corresponding full conditionals!!!
  # THIRD BLOCK of G-S
  # NOTE THAT NOW I MUST IMPUTE 
  # THE MISSING VALUES IN THE APPROPRIATE WAY ....
  # head(pima)
  for(r in 1:nrow(current_multi_normal_data)){
    # indicators of missing data in the original pima data
    ind_m=is.na(pima[r,])
    ind_o=!ind_m
    m=which(ind_m)
    o=which(ind_o)
    # if there is at least one missing data 
    # impute them using the full conditional
    # otherwise ... do nothing!!
    
    if(any(ind_m)){
      # compute the parameters of the normal distribution corresponding to the 
      # conditional distribution of unobserved components 
      # given the observed ones corresponding to the same unit.
      Sigma_o_inv=solve(Sigma[ind_o,ind_o])
      beta_cond_m=Sigma[ind_m,ind_o]%*%Sigma_o_inv # green vector at slide p. 225
          # corresponding to the coefficient of the linear regression function 
      cond_Sigma_m=Sigma[ind_m,ind_m]-Sigma[ind_m,ind_o]%*%Sigma_o_inv%*%Sigma[ind_o,ind_m]
      # the conditional expectation (i.e. the mean of the mvnormal distribution we should draw from 
      # has a linear regression function formula)
      cond_mu_m=theta[ind_m]+beta_cond_m%*%(t(current_multi_normal_data[r,ind_o])-theta[ind_o])
      # here we finally draw from the full-conditional 
      current_multi_normal_data[r,ind_m]=rmvnorm(1,cond_mu_m,cond_Sigma_m)
    }
  }
  
  # make a copy of complete data containing the 
  # the imputed data during the i-th gibbs cycle
  
  array_with_inferred_imputed_data[,,i]=as.matrix(current_multi_normal_data)

  # after imputing the missing data with new randomly chosen (according to a specific rule) we should take care that the complete-data summary statistics (like the sample means) needed for GS must be re-computed for the next iteration .... see the first line of the Gibbs cycle
  
}

o2 <- proc.time()
o2-o1

dim(array_with_inferred_imputed_data)
array_with_inferred_imputed_data[,,1]
array_with_inferred_imputed_data[,,2]
# remove the first initialization row [so that no NA are there]

array_with_inferred_imputed_data = array_with_inferred_imputed_data[,,-1]
dim(array_with_inferred_imputed_data)
gibbs_sample_theta=gibbs_sample_theta[-1,]
dim(gibbs_sample_theta)
gibbs_sample_Sigma=gibbs_sample_Sigma[,,-1]
dim(gibbs_sample_Sigma)

head(gibbs_sample_theta)
gibbs_sample_Sigma[,,1:6]
array_with_inferred_imputed_data[1:4,,1:6]

# now we can check that 
# there are no missing values in the array
any(is.na(array_with_inferred_imputed_data))

### 10. Inferring the unknown parameters ----

# ..... posterior estimates of the tehta parameter: apply(gibbs_sample_theta,2,mean)

dim(gibbs_sample_theta)

colMeans(gibbs_sample_theta)

hist(gibbs_sample_theta[,1],prob=TRUE)
lines(density(gibbs_sample_theta[,1]))
sd(gibbs_sample_theta[,1])

# ET interval
quantile(gibbs_sample_theta[,1],c(0.025,0.975))
abline(v=quantile(gibbs_sample_theta[,1],c(0.025,0.975)))

# standard deviations of the posterior distribution of 
# the components of the theta vector
# considering all the available data (with possibly missing entries)
sd_all_with_missing <- apply(gibbs_sample_theta,2,sd)
sd_all_with_missing

### 11. Inferring the missing data ----

dim(array_with_inferred_imputed_data)

pima[1,]
# the first woman has all available measurements

# in which case there is no point in looking at the 
# 999 slices of the array_with_inferred_imputed_data
# corresponding to that woman 
# here we can see in the first 6 slices that 
# there are nothing but replications of the initially available data ...
t(array_with_inferred_imputed_data[1,,1:6])

# corresponding to 
pima[1,]

# suppose now we want to infer on the 
# missing data corresponding to the woman 
# labelled as 181
# corresponding to the 181st row 
# of the pima data.frame
pima[181,]

# if we focus on the 4-th measurement (bmi) 
# corrsponding to unit 181 
# for all the 999 recorded Gibbs iterations 

dim(array_with_inferred_imputed_data[181,,])

t(array_with_inferred_imputed_data[181,,1:6])
head(array_with_inferred_imputed_data[181,4,])
array_with_inferred_imputed_data[181,4,]
length(array_with_inferred_imputed_data[181,4,])

# this may be useful to understand .... 
# t(array_with_inferred_imputed_data[181,3:4,])

par(mfrow=c(1,1))
# we can have an overall approximated idea 
# of the conditional "predictive" distribution 
# of that missing bmi data of that 181st woman
hist(array_with_inferred_imputed_data[181,4,],xlab="bmi",main="Conditional predictive distribution \n of the missing bmi the for woman labelled as 181",prob=TRUE)
box()

# which can be summarized with a 
# point "prediction" 
mean(array_with_inferred_imputed_data[181,4,])


# if we want to assess
# (approx. estimate) prediction uncertainty
# we can look at the 
# stardard deviation of the (cond.) predictive distribution
sqrt(var(array_with_inferred_imputed_data[181,4,]))

# we can also quantify the amount of uncertainty 
# with an equal-tail prediction interval 
quantile(array_with_inferred_imputed_data[181,4,],probs=c(0.025,0.975))
# cbind(quantile(array_with_inferred_imputed_data[181,4,],probs=c(0.025,0.975)),c(0,0))
points(cbind(quantile(array_with_inferred_imputed_data[181,4,],probs=c(0.025,0.975)),c(0,0)),pch=15,cex=3,col="blue")

box()
points(mean(array_with_inferred_imputed_data[181,4,]),0,pch=17,col="red",cex=2)

lines(density(array_with_inferred_imputed_data[181,4,]),col="orange",lwd=3)

 
### 12. Highlighting the role of the information available in the other available variables ----


head(pima)
sum(complete.cases(pima[,3:4]))
plot(pima[,3],pima[,4],xlab=names(pima)[3],ylab=names(pima)[4]) # how many point in this cloud? 
points(pima[181,3],pima[181,4],col="red",pch=16) # no point is highlighted in red ... can you understand why? 

pima[181,]
# sum(complete.cases(pima[,3:4])) and sum(!complete.cases(pima[,3:4]))

points(pima[181,3],mean(array_with_inferred_imputed_data[181,4,]),col="red",pch=17,cex=2) # .... imputation 
y_bar_n <- colMeans(pima,na.rm=TRUE) # we need to recompute with the original dataset with missing entries
abline(v=y_bar_n[3])
abline(h=y_bar_n[4])
points(pima[181,3],y_bar_n[4],col="blue",pch=16,cex=2) # .... imputation

legend(x="topright",pch=c(17,16),col=c("red","blue"),legend=c("imputed via conditioning on available","imputed with a rule of thumb"))

mean(pima[,4],na.rm=TRUE)
pima[181,]


### 13. Bayesian inference on ***derived parameters*** psi=g(theta,Sigma) [via MCMC approximations] ----

ls()
dim(gibbs_sample_Sigma)


### 14. Infer on the partial regression coefficients ----
names(pima)

# y_4 is the same as y_bmi

# remember the difference between partial regression coefficients with multiple covariates (other)
# E[y_bmi|y_glu,y_bp,y_skin] = beta_0 + beta_1 y_glu + beta_2 y_bp + beta_3 y_skin 
# E[y_4|y_1,y_2,y_3] = beta_0 + beta_1 y_1 + beta_2 y_2 + beta_3 y_3 

# and regression coefficients with a ***single*** covariate (the third one)
# E[y_4|y_3] =  alpha + beta_y4_given_3*y_3

beta_y4_given_other <- matrix(NA,nrow=999,ncol=3)

# beta_y4_given_3 <- rep(NA,999)

gibbs_sample_Sigma[,,1:6]

# here we basically re-manipulate the output of the 999
# simulations of the (theta^(g),Sigma^(g)) parameter obtained from GS
# and derive the corresponding simulations of the derived parameters
# psi^(g)=g(theta^(g),Sigma^(g))

g <- 1
dim(gibbs_sample_Sigma)
gibbs_sample_Sigma[,,g]
for(g in 1:999){

# derived g-th simulation of the derived vector parameter beta_4_given_other
  
beta_y4_given_other[g,] <- gibbs_sample_Sigma[4,1:3,g]%*%solve(gibbs_sample_Sigma[1:3,1:3,g])

# highlighted with DarkGreen color in the slides (about p.199)

}

head(beta_y4_given_other)
beta_y4_given_other[1:6,]

beta_y4_given_1 <- beta_y4_given_other[,1]
beta_y4_given_2 <- beta_y4_given_other[,2]
beta_y4_given_3 <- beta_y4_given_other[,3]

par(mfrow=c(3,1))
hist(beta_y4_given_other[,1],xlim=c(-0.06,0.7))
box()
abline(v=0,lwd=4,col="red")
hist(beta_y4_given_other[,2],xlim=c(-0.06,0.7))
box()
abline(v=0,lwd=4,col="red")
hist(beta_y4_given_other[,3],xlim=c(-0.06,0.7)) # box()
box()
abline(v=0,lwd=4,col="red")
# approximation of the posterior distribution of beta_y4_given_3

names(pima)

par(mfrow=c(2,2))
#par(mfrow=c(1,1))
plot(pima[,1],pima[,4],xlab=names(pima)[1],ylab=names(pima)[4])

#par(mfrow=c(1,1))
plot(pima[,2],pima[,4],xlab=names(pima)[2],ylab=names(pima)[4])

#par(mfrow=c(1,1))
plot(pima[,3],pima[,4],xlab=names(pima)[3],ylab=names(pima)[4])

gibbs_sample_Sigma[,,1]

### 15. Inference on the correlation coefficients ----

gibbs_sample_correlation <- array(NA,dim=c(4,4,999))

g <- 1

gibbs_sample_Sigma[,,1] # variances and covariances (numerator)
diag(gibbs_sample_Sigma[,,1])%o%diag(gibbs_sample_Sigma[,,1]) 
# alternatively 
diag(gibbs_sample_Sigma[,,1])%*%t(diag(gibbs_sample_Sigma[,,1]))

102.47135^2
942.580037*104.36187
# cross product of variances at the denominator (taking the the square root)

g <- 1

r <- 1:3
c <- seq(10,30,10)
r
c
r%o%c # outer product
outer(r,c,FUN="*")

# outer(r,c,FUN="+")

for(g in 1:999){
# we will compute another deterministic h(...) function of the simultated "output" (theta,Sigma,y_[m]) [in fact a function of (theta,Sigma) only]
  
# derived g-th simulation of the corresponding  correlation matrix

gibbs_sample_correlation[,,g] <- gibbs_sample_Sigma[,,g]/sqrt(diag(gibbs_sample_Sigma[,,g])%o%diag(gibbs_sample_Sigma[,,g]))
  
}

dim(gibbs_sample_correlation)
gibbs_sample_correlation[,,1:3]

# we can infer, for instance, on the correlation between bp and bmi

quantile(gibbs_sample_correlation[2,4,],0.025)
quantile(gibbs_sample_correlation[2,4,],0.975)
par(mfrow=c(1,1))
hist(gibbs_sample_correlation[2,4,])
points(quantile(gibbs_sample_correlation[2,4,],0.025),0,pch=17,col="blue",cex=2)
points(quantile(gibbs_sample_correlation[2,4,],0.975),0,pch=17,col="blue",cex=2)

mean(gibbs_sample_correlation[2,4,])

quantile(gibbs_sample_correlation[3,4,],0.025)
quantile(gibbs_sample_correlation[3,4,],0.975)
par(mfrow=c(1,1))
hist(gibbs_sample_correlation[3,4,])
points(quantile(gibbs_sample_correlation[3,4,],0.025),0,pch=17,col="blue",cex=2)
points(quantile(gibbs_sample_correlation[3,4,],0.975),0,pch=17,col="blue",cex=2)


# we can test 
# H_0: rho_{2,4}=corr(bp,bmi) >= 0.3
# H_1: rho_{2,4}=corr(bp,bmi) < 0.3
mean(gibbs_sample_correlation[2,4,]>=0.3)
mean(gibbs_sample_correlation[2,4,]<0.3)

# we can infer, for instance, on the correlation between glu and skin

length(gibbs_sample_correlation[1,3,])
hist(gibbs_sample_correlation[1,3,])
mean(gibbs_sample_correlation[1,3,]) # point estimate
points(mean(gibbs_sample_correlation[1,3,]),0,col="red",pch=16,cex=4)

# please verify you understand the apply(...) function with arrays we understand why this is an approximation of the posterior expectations of all entries of the correlation matrix corresponding to the unknown Sigma matrix

# quick way to get estimates of all the possible correlations
apply(gibbs_sample_correlation[,,],c(1,2),mean)
post_mean_rho_approx <- apply(gibbs_sample_correlation[,,],c(1,2),mean)
# with the help of the apply function 

hist(gibbs_sample_correlation[3,4,])
points(post_mean_rho_approx[3,4],0,col="red",pch=16,cex=2)
hist(gibbs_sample_correlation[1,3,])
# points(post_mean_rho_approx[1,3],0,col="red",pch=16,cex=2)
head(pima)



#  derive the same plot as in Fig. 7.4 page 121 of PH book
# 

# ....


# any volunteer?


### 16. OUT OF SAMPLE VALIDATION OF IMPUTATION BY CONDITIONING ON ALL ACTUALLY OBSERVED DATA  ----

## indeed missing data were taken out
## completely at random from the 
## original data 

# pima_full=dget("http://www.stat.washington.edu/people/pdhoff/Book/Data/data/Y.pima_full")
# write.csv(pima_full,file="pima-full.csv",row.names=FALSE)

pima_full= read.csv("pima-full.csv")
any(is.na(pima_full))
head(pima_full)
head(pima)

pima[181,]      
pima_full[181,]

is.na(pima[,4])
which(is.na(pima[,4]))
true_data_bmi=pima_full[is.na(pima[,4]),4]
length(true_data_bmi)

dim(array_with_inferred_imputed_data)
dim(array_with_inferred_imputed_data[is.na(pima[,4]),4,])

imputed_bmi=apply(array_with_inferred_imputed_data[is.na(pima[,4]),4,],1,mean)
length(imputed_bmi)

par(mfrow=c(1,1))
plot(true_data_bmi,imputed_bmi)
abline(0,1)
cor(true_data_bmi,imputed_bmi)

# prediction error using Bayesian imputation
sqrt(mean((true_data_bmi-imputed_bmi)^2))

pima.thumb <- pima
pima.thumb$bmi <- mean(pima$bmi,na.rm=TRUE)
# to siplify we are replacing all the entries of the bmi column with the overall sample mean of the available bmi data 
# otherwise, more rigorously 

head(pima)

pima.thumb <- pima
# replace all the entries in the bmi column with a column with a single entry 
# equal to the available bmi data average
pima.thumb$bmi[is.na(pima[,4])] <- mean(pima$bmi,na.rm=TRUE)

head(pima.thumb)

sqrt(mean((true_data_bmi-pima.thumb$bmi[is.na(pima[,4])])^2))

# this would be the prediction error using the thumb rule

# can we appreciate how much the thumb rule would be 
# inefficient in terms of prediction error?

thumb_bmi_imputation <- mean(pima.thumb$bmi,na.rm=TRUE)
abline(h=thumb_bmi_imputation)

sqrt(mean((true_data_bmi-imputed_bmi)^2))
# this is the prediction error using the Bayesian approach

sqrt(mean((true_data_bmi-thumb_bmi_imputation)^2))
# this is the prediction error using the thumb rule

sqrt(mean((true_data_bmi-thumb_bmi_imputation)^2))/sqrt(mean((true_data_bmi-imputed_bmi)^2))
# 22% of inefficiency

mean((true_data_bmi-thumb_bmi_imputation)^2)/mean((true_data_bmi-imputed_bmi)^2)

# at the end of this session we should be able 
# to understand, support and empirically verify 
# the following two main claims: 

# - removing missing data is INEFFICIENT 
#   (compare the standard deviations for 
#    the posterior distribution of theta)
# 

# - replacing missing data with 
#   fixed/constant imputed values is STATISTICALLY INCORRECT

### set of available data
### removing all the rows containing NA's
head(pima)

pima_reduced <- pima[complete.cases(pima),]
dim(pima_reduced)
# we get complete measurements only in 127 women
reduced_n <- nrow(pima_reduced)
  
current_multi_normal_data <- as.matrix(pima_reduced)
# now the current_multi_normal_data obbject contains the REDUCED dataset 

any(is.na(current_multi_normal_data)) # now there is NO missing data in the reduced dataset

# that's why we can compute 
y_bar_n <- colMeans(current_multi_normal_data)
# outside the for loop 
# In fact, it will be always the same.

i=2

# now we rerun the Gibbs Sampling to show that 
# the posterior inference is less efficient 
# in estimating the parameters (take theta[1] for instance)

dim(current_multi_normal_data)
for(i in 2:nrow(gibbs_sample_theta)){
  
#    print(i)
  
  # sample Sigma from the current full-conditional
  # or better sample its inverse first
  # using the rWishart(...) function
  
  S_theta= (t(current_multi_normal_data)-theta)%*%t((t(current_multi_normal_data)-theta))
  
  S_n = S_0 + S_theta
  
  Sigma=solve(rWishart(n=1,df=reduced_n+nu_0,Sigma = solve(S_n))[,,1])
  
  # NOTE THAT Sigma = ... is the syntax for the argument of the rWishart function!! It corresponds to our S argument/parameter of the Wishart
  
  # record the sampled covariance matrix
  gibbs_sample_Sigma[,,i]=Sigma
  # now Sigma is the current/update covariance matrix and we condition on this Sigma matrix to sample the mean vector theta
  
  # compute the new parameters of the full conditionals
  Lambda_n = solve( solve(Lambda_0) + reduced_n*solve(Sigma))
  mu_n = Lambda_n%*%(solve(Lambda_0)%*%mu_0 + reduced_n *solve(Sigma)%*%y_bar_n)
  theta=c(rmvnorm(n=1,mean=mu_n,sigma=Lambda_n))
  gibbs_sample_theta[i,]=theta
  

}

sd_reduced <- apply(gibbs_sample_theta,2,sd)
sd_reduced
sd_all_with_missing

# 

# now we could also see that if we used the 
# original dataset with no missing data 
# we could be even more efficient ....

pima_full
n <- nrow(pima_full)

# again we can compute 
y_bar_n <- colMeans(pima_full)
# outside the for loop 
# In fact, it will be always the same.

for(i in 2:nrow(gibbs_sample_theta)){
  
  #    print(i)
  
  
  # sample Sigma from the current full-conditional
  # or better sample its inverse first
  # using the rWishart(...) function
  
  S_theta= (t(pima_full)-theta)%*%t((t(pima_full)-theta))
  
  S_n = S_0 + S_theta
  
  Sigma=solve(rWishart(n=1,df=n+nu_0,Sigma = solve(S_n))[,,1])
  
  # NOTE THAT Sigma = ... is the syntax for the argument of the rWishart function!! It corresponds to our S argument/parameter of the Wishart
  
  # record the sampled covariance matrix
  gibbs_sample_Sigma[,,i]=Sigma
  # now Sigma is the current/update covariance matrix and we condition on this Sigma matrix to sample the mean vector theta
  
  # compute the new parameters of the full conditionals
  Lambda_n = solve( solve(Lambda_0) + n *solve(Sigma))
  mu_n = Lambda_n%*%(solve(Lambda_0)%*%mu_0 + n *solve(Sigma)%*%y_bar_n)
  theta=c(rmvnorm(n=1,mean=mu_n,sigma=Lambda_n))
  gibbs_sample_theta[i,]=theta
}

apply(gibbs_sample_theta,2,sd)

sd_all_with_no_missing <- apply(gibbs_sample_theta,2,sd)
sd_all_with_no_missing
sd_reduced
sd_all_with_missing

#### 
apply(pima_full,2,sd)
apply(pima,2,sd,na.rm=TRUE)

head(pima)
mean(pima[,4],na.rm=TRUE)

plot(pima[,3:4])
points(pima[2,3],pima[2,4])
points(pima[2,3],pima_full[2,4],pch=16,col="red",cex=3)
abline(h=mean(pima[,4],na.rm=TRUE))
abline(v=mean(pima[,3],na.rm=TRUE))


# let's try with another unit
# and discuss whether it can be useful to exploit the info contained in the other measurements of a single unit in order to infer on the missing data entry 

plot(pima[,3:4])
points(pima[181,3],pima[181,4])
points(pima[181,3],pima_full[181,4],pch=16,col="red",cex=3)
abline(h=mean(pima[,4],na.rm=TRUE))
abline(v=mean(pima[,3],na.rm=TRUE))

pima[181,]

# indeed we would like to take into account all the possible useful available information on the other 3 measurements (glu, bp and bmi)

# what is the equation of the regression which takes into account all the other 3 measurements? 

# here is an "estimate" of the partial regression coefficients based on the posterior distribution of the unknown parameters

dim(beta_y4_given_other)
apply(beta_y4_given_other,2,mean)

#  ===> bmi = 0.004085337*glu+0.044817838*bp+0.2969098*skin + error ...

# what would be the Bayesian estimate for this other regression :
# bmi = alpha + beta_bmi_skin*skin + error
# alpha ? 
# beta ? 

# can you understand the difference between the partial regression coefficient beta_y4_given_other[3] and the second beta?

# final remark: to get a "better" approximation  
# you should re-run the inference with a larger nsim value 
# (say 10000 instead of 1000) 
# and discarding a "sufficient" number (burn_in=1000) of initial iterations


